Yakub Store — প্রাথমিক ওয়েবসাইট ডেমো

চালানোর নিয়ম:
1. ZIP ফাইলটি extract করুন।
2. index.html ফাইলটি Chrome বা অন্য ব্রাউজারে খুলুন।

যা আছে:
- বাংলা, সবুজ-সাদা responsive storefront
- হলুদের পণ্য কার্ড
- কার্ট ও পরিমাণ পরিবর্তন
- ডেমো checkout form
- লোকাল ব্রাউজারে ডেমো অর্ডার সংরক্ষণ
- CSV export

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি এখনও live ecommerce backend নয়।
- অর্ডার দোকানদারের কাছে পাঠানো হয় না; ডেটা শুধু একই ব্রাউজারে থাকে।
- admin area demo-only; login/authentication নেই।
- bKash/Nagad কোনো real payment transaction করে না।
- Lucky Strike ও Black Diamond তামাকজাত পণ্য হিসেবে এই ডেমোতে order-disabled।
- সারা বাংলাদেশে ডেলিভারি, courier integration, privacy/security, domain এবং payment gateway আলাদাভাবে সেটআপ করতে হবে।

ফ্রি হোস্টিংয়ের সম্ভাব্য পথ:
- GitHub Pages-এ static demo প্রকাশ করা যায় (GitHub account লাগবে)। তবে static hosting একা secure order database বা real checkout দেয় না।
- পূর্ণাঙ্গ দোকানের জন্য backend/database এবং পেমেন্ট/ডেলিভারি integration লাগবে; এসবের free-tier সীমা ও শর্ত বদলাতে পারে।
